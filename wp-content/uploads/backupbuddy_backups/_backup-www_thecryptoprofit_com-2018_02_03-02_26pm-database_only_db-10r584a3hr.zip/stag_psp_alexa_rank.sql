CREATE TABLE `stag_psp_alexa_rank` (  `id` int(10) NOT NULL AUTO_INCREMENT,  `domain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',  `global_rank` int(10) NOT NULL DEFAULT '0',  `rank_delta` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',  `country_rank` int(10) NOT NULL DEFAULT '0',  `country_code` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',  `country_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',  `update_date` date NOT NULL,  PRIMARY KEY (`id`),  UNIQUE KEY `update_date` (`update_date`)) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40000 ALTER TABLE `stag_psp_alexa_rank` DISABLE KEYS */;
INSERT INTO `stag_psp_alexa_rank` VALUES('1', 'thecryptoprofit.com', '15421783', '', '0', '', '', '2018-01-28');
INSERT INTO `stag_psp_alexa_rank` VALUES('2', 'thecryptoprofit.com', '15421783', '', '0', '', '', '2018-01-29');
INSERT INTO `stag_psp_alexa_rank` VALUES('3', 'thecryptoprofit.com', '15425888', '', '0', '', '', '2018-01-30');
INSERT INTO `stag_psp_alexa_rank` VALUES('4', 'thecryptoprofit.com', '15442701', '', '0', '', '', '2018-01-31');
INSERT INTO `stag_psp_alexa_rank` VALUES('5', 'thecryptoprofit.com', '15471976', '', '0', '', '', '2018-02-03');
/*!40000 ALTER TABLE `stag_psp_alexa_rank` ENABLE KEYS */;
