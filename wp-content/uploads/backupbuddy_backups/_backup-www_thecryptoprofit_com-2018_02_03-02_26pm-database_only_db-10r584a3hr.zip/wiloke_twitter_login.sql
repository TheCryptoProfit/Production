CREATE TABLE `wiloke_twitter_login` (  `author_id` mediumint(9) NOT NULL,  `twitter_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,  UNIQUE KEY `author_id` (`author_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `wiloke_twitter_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiloke_twitter_login` ENABLE KEYS */;
