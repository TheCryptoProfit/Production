CREATE TABLE `stag_ff_image_cache` (  `url` varchar(50) NOT NULL,  `width` int(11) DEFAULT NULL,  `height` int(11) DEFAULT NULL,  `creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `original_url` varchar(300) DEFAULT NULL,  PRIMARY KEY (`url`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40000 ALTER TABLE `stag_ff_image_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_ff_image_cache` ENABLE KEYS */;
