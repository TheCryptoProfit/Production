CREATE TABLE `stag_psp_serprank_keyword` (  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,  `keyword` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,  `search_engine` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'google.com',  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  PRIMARY KEY (`id`),  UNIQUE KEY `keyword` (`keyword`,`search_engine`),  KEY `search_engine` (`search_engine`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40000 ALTER TABLE `stag_psp_serprank_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_psp_serprank_keyword` ENABLE KEYS */;
