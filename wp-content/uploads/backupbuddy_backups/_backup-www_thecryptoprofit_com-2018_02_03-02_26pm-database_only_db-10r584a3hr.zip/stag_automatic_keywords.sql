CREATE TABLE `stag_automatic_keywords` (  `keyword_id` int(11) NOT NULL AUTO_INCREMENT,  `keyword_name` varchar(250) NOT NULL,  `keyword_camp` int(11) NOT NULL,  `keyword_start` int(11) NOT NULL DEFAULT '0',  `clickbank_start` int(11) NOT NULL DEFAULT '1',  `amazon_start` int(11) NOT NULL DEFAULT '1',  PRIMARY KEY (`keyword_id`),  UNIQUE KEY `keyword_name` (`keyword_name`,`keyword_camp`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_automatic_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_automatic_keywords` ENABLE KEYS */;
