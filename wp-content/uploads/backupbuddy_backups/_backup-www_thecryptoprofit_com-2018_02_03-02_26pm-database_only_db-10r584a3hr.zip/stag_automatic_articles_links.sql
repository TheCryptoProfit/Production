CREATE TABLE `stag_automatic_articles_links` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `link` varchar(300) NOT NULL,  `keyword` varchar(300) NOT NULL,  `page_num` int(11) NOT NULL,  `status` int(2) NOT NULL DEFAULT '0',  `title` mediumtext NOT NULL,  `bing_cache` mediumtext NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_automatic_articles_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_automatic_articles_links` ENABLE KEYS */;
