CREATE TABLE `stag_psp_web_directories` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `directory_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,  `submit_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,  `pagerank` double DEFAULT NULL,  `alexa` double DEFAULT NULL,  `status` smallint(1) DEFAULT '0',  PRIMARY KEY (`id`),  UNIQUE KEY `submit_url` (`submit_url`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40000 ALTER TABLE `stag_psp_web_directories` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_psp_web_directories` ENABLE KEYS */;
