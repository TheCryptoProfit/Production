CREATE TABLE `stag_ff_snapshots` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `description` varchar(20) DEFAULT NULL,  `creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `settings` longtext NOT NULL,  `fb_settings` longtext,  `version` varchar(10) NOT NULL DEFAULT '2.0',  `dump` blob,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40000 ALTER TABLE `stag_ff_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_ff_snapshots` ENABLE KEYS */;
