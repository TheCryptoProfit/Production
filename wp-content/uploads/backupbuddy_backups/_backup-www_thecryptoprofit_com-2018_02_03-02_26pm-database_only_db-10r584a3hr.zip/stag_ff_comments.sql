CREATE TABLE `stag_ff_comments` (  `id` varchar(50) NOT NULL,  `post_id` varchar(50) NOT NULL,  `from` blob,  `text` longblob,  `created_time` int(11) DEFAULT NULL,  `updated_time` int(11) DEFAULT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40000 ALTER TABLE `stag_ff_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_ff_comments` ENABLE KEYS */;
