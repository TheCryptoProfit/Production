CREATE TABLE `stag_automatic_clickbank_links` (  `link_url` varchar(500) NOT NULL,  `link_title` varchar(500) NOT NULL,  `link_keyword` varchar(300) NOT NULL,  `link_status` varchar(20) NOT NULL,  `link_id` int(11) NOT NULL AUTO_INCREMENT,  `link_desc` mediumtext NOT NULL,  PRIMARY KEY (`link_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_automatic_clickbank_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_automatic_clickbank_links` ENABLE KEYS */;
