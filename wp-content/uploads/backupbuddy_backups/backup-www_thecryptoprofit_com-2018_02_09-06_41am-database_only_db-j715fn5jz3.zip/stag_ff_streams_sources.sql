CREATE TABLE `stag_ff_streams_sources` (  `feed_id` varchar(20) NOT NULL,  `stream_id` int(11) NOT NULL,  PRIMARY KEY (`feed_id`,`stream_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40000 ALTER TABLE `stag_ff_streams_sources` DISABLE KEYS */;
INSERT INTO `stag_ff_streams_sources` VALUES('jo26790', '2');
INSERT INTO `stag_ff_streams_sources` VALUES('le90436', '1');
INSERT INTO `stag_ff_streams_sources` VALUES('le90436', '2');
INSERT INTO `stag_ff_streams_sources` VALUES('qr51235', '2');
INSERT INTO `stag_ff_streams_sources` VALUES('wh35006', '2');
/*!40000 ALTER TABLE `stag_ff_streams_sources` ENABLE KEYS */;
