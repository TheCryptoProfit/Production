CREATE TABLE `stag_wpr_errors` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `campaign` bigint(20) NOT NULL,  `keyword` varchar(255) NOT NULL,  `module` varchar(255) NOT NULL,  `reason` varchar(255) NOT NULL,  `message` longtext NOT NULL,  `time` varchar(255) NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40000 ALTER TABLE `stag_wpr_errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_wpr_errors` ENABLE KEYS */;
