CREATE TABLE `stag_cm_campaign_categories` (  `category_id` int(11) NOT NULL AUTO_INCREMENT,  `category_title` varchar(150) NOT NULL,  PRIMARY KEY (`category_id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_cm_campaign_categories` DISABLE KEYS */;
INSERT INTO `stag_cm_campaign_categories` VALUES('1', 'www.thecryptoprofit.com');
/*!40000 ALTER TABLE `stag_cm_campaign_categories` ENABLE KEYS */;
