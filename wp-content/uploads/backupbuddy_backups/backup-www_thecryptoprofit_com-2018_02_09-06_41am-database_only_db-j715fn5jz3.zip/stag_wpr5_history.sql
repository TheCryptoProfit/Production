CREATE TABLE `stag_wpr5_history` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `cid` bigint(20) NOT NULL,  `pid` bigint(20) NOT NULL,  `module_errors` longtext NOT NULL,  `title` varchar(255) NOT NULL,  `keyword` varchar(255) NOT NULL,  `template` varchar(25) NOT NULL,  `time` varchar(255) NOT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40000 ALTER TABLE `stag_wpr5_history` DISABLE KEYS */;
INSERT INTO `stag_wpr5_history` VALUES('3', '0', '0', '', 'No content found.', '', '0', '1517882074');
/*!40000 ALTER TABLE `stag_wpr5_history` ENABLE KEYS */;
