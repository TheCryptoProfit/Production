CREATE TABLE `stag_cm_campaign_categories_rel` (  `campaign_cat_rel_id` int(11) NOT NULL AUTO_INCREMENT,  `campaign_id` int(11) NOT NULL,  `category_id` int(11) NOT NULL,  PRIMARY KEY (`campaign_cat_rel_id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_cm_campaign_categories_rel` DISABLE KEYS */;
INSERT INTO `stag_cm_campaign_categories_rel` VALUES('1', '1', '1');
/*!40000 ALTER TABLE `stag_cm_campaign_categories_rel` ENABLE KEYS */;
