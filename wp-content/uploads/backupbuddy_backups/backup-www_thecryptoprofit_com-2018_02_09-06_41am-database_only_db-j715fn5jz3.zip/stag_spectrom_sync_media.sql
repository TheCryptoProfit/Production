CREATE TABLE `stag_spectrom_sync_media` (  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,  `site_key` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `remote_media_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `local_media_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,  PRIMARY KEY (`id`),  KEY `site_key` (`site_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `stag_spectrom_sync_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_spectrom_sync_media` ENABLE KEYS */;
