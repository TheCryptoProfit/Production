CREATE TABLE `stag_psp_serp_reporter2rank` (  `id` int(10) NOT NULL AUTO_INCREMENT,  `report_id` int(10) DEFAULT '0',  `report_day` date DEFAULT NULL,  `position` int(10) DEFAULT '0',  `top100` text COLLATE utf8_unicode_ci,  PRIMARY KEY (`id`),  UNIQUE KEY `unique` (`report_id`,`report_day`),  KEY `report_day` (`report_day`),  KEY `position` (`position`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40000 ALTER TABLE `stag_psp_serp_reporter2rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_psp_serp_reporter2rank` ENABLE KEYS */;
