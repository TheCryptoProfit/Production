CREATE TABLE `stag_automatic_feeds_links` (  `camp_id` varchar(150) NOT NULL,  `link` varchar(300) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_automatic_feeds_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_automatic_feeds_links` ENABLE KEYS */;
