CREATE TABLE `stag_automatic_general` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `item_id` varchar(50) NOT NULL,  `item_type` text NOT NULL,  `item_status` varchar(50) NOT NULL,  `item_data` mediumtext NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_automatic_general` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_automatic_general` ENABLE KEYS */;
