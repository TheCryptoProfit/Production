CREATE TABLE `stag_automatic_cached` (  `img_id` int(11) NOT NULL AUTO_INCREMENT,  `img_external` text NOT NULL,  `img_internal` text NOT NULL,  `img_path` text NOT NULL,  `img_hash` varchar(50) NOT NULL,  `img_data_hash` varchar(50) NOT NULL,  PRIMARY KEY (`img_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_automatic_cached` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_automatic_cached` ENABLE KEYS */;
