CREATE TABLE `stag_wpr_posts` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `campaign` bigint(20) NOT NULL,  `keyword` varchar(255) NOT NULL,  `module` varchar(255) NOT NULL,  `unique_id` longtext NOT NULL,  `time` varchar(255) NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40000 ALTER TABLE `stag_wpr_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_wpr_posts` ENABLE KEYS */;
