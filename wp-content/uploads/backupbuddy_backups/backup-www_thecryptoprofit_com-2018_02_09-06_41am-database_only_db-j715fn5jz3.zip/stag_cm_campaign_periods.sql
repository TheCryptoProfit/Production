CREATE TABLE `stag_cm_campaign_periods` (  `period_id` int(11) NOT NULL AUTO_INCREMENT,  `campaign_id` int(11) NOT NULL,  `date_from` datetime NOT NULL,  `date_till` datetime NOT NULL,  PRIMARY KEY (`period_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_cm_campaign_periods` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_cm_campaign_periods` ENABLE KEYS */;
