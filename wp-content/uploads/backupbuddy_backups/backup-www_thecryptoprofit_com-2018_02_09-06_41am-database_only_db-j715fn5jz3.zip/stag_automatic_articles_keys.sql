CREATE TABLE `stag_automatic_articles_keys` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `camp_id` int(11) NOT NULL,  `keyword` varchar(200) NOT NULL,  `page_num` int(11) NOT NULL DEFAULT '0',  `status` int(11) NOT NULL DEFAULT '0',  `last_page` int(11) NOT NULL DEFAULT '999',  `articlesbase_lastadd` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',  PRIMARY KEY (`id`),  UNIQUE KEY `uc_keywordID` (`camp_id`,`keyword`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `stag_automatic_articles_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_automatic_articles_keys` ENABLE KEYS */;
