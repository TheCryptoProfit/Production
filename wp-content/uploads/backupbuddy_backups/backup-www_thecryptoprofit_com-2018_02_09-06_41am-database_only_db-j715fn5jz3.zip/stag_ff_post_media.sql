CREATE TABLE `stag_ff_post_media` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `feed_id` varchar(20) NOT NULL,  `post_id` varchar(50) NOT NULL,  `post_type` varchar(10) NOT NULL,  `media_url` text,  `media_width` int(11) DEFAULT NULL,  `media_height` int(11) DEFAULT NULL,  `media_type` varchar(100) DEFAULT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40000 ALTER TABLE `stag_ff_post_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `stag_ff_post_media` ENABLE KEYS */;
