<?php # -*- coding: utf-8 -*-

namespace Requisite\Rule;

/**
 * Class NamespaceDirectoryMapper
 *
 * Alias of Psr4, provided for backward compatibility
 * 
 * @deprecated 
 * @package Requisite\Rule
 */
class NamespaceDirectoryMapper extends Psr4 implements AutoLoadRuleInterface {}
