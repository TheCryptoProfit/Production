<?php
/*** INFO ARRAY ***/
$wpr5_source_infos = array(
	"categories" => array(
		"rewriting" => array(
			"name" => "Rewriting and Translation",
			"description" => "",
			"sources" => array("spinnerchief", "spinchimp", "spinrewriter", "thebestspinner", "wordai")
		),
		"comments" => array(
			"name" => "Content with Comments / Answers",
			"description" => "",
			"sources" => array("flickr", "youtube")
		),	
		"shopping" => array(
			"name" => "Shopping, Products and Affiliate Networks",
			"description" => "",
			"sources" => array("aliexpress", "amazon", "avantlink", "bestbuy", "commissionjunction", "datafeed", "ebay", "etsy", "expedia", "linkshare", "shopzilla", "skimlinks", "tradedoubler", "walmart", "zanox")
		),	
		"content" => array(
			"name" => "Content",
			"description" => "",
			"sources" => array("articles", "datafeed", "eventful", "expedia", "indeed", "itunes", "oodle", "rottentomatoes", "rss", "yelp")
		),
		"media" => array(
			"name" => "Pictures and Videos",
			"description" => "",
			"sources" => array("flickr", "pixabay", "youtube", "vimeo")
		),
		"regional" => array(
			"name" => "Regional Targeted Content",
			"description" => "",
			"sources" => array("eventful", "indeed", "oodle", "yelp")
		),					
	),
	"languages" => array(
		"de" => array(
			"name" => "German",
			"icon" => "",
			"sources" => array("amazon", "commissionjunction", "datafeed", "ebay", "shopzilla", "youtube" )
		),	
		"es" => array(
			"name" => "Spanish",
			"icon" => "",
			"sources" => array("amazon", "ebay", "youtube", "datafeed")
		),	
		"fr" => array(
			"name" => "French",
			"icon" => "",
			"sources" => array("amazon", "datafeed", "ebay", "shopzilla", "youtube" )
		),			
		"it" => array(
			"name" => "Italian",
			"icon" => "",
			"sources" => array("amazon", "datafeed", "ebay", "youtube" )
		),	
		"pt" => array(
			"name" => "Portuguese",
			"icon" => "",
			"sources" => array("youtube", "datafeed")
		),	
		"nl" => array(
			"name" => "Dutch",
			"icon" => "",
			"sources" => array("youtube", "ebay", "datafeed")
		),			
		"ru" => array(
			"name" => "Russian",
			"icon" => "",
			"sources" => array("datafeed", "youtube" )
		),			
		"jp" => array(
			"name" => "Japanese",
			"icon" => "",
			"sources" => array("amazon", "datafeed", "itunes", "youtube" )
		),	
		"zn" => array(
			"name" => "Chinese",
			"icon" => "",
			"sources" => array("datafeed", "ebay", "youtube" )
		),				
	),		
	"sources" => array(
		"aliexpress" => array(
			"name" => "AliExpress",		
			"limits" => array("request" => 40, "total" => 100),		
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "https://portals.aliexpress.com/help/help_center_API.html"
		),
		"amazon" => array(
			"name" => "Amazon",		
			"limits" => array("request" => 10, "total" => 100),		
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "https://affiliate-program.amazon.com/gp/advertising/api/detail/main.html"
		),
		"articlebuilder" => array(
			"name" => "Article Builder",			
			"limits" => array("request" => 1, "total" => 10),			
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "http://paydotcom.net/r/114431/thoefter/26922760/",
			"paid" => 1
		),	
		"articles" => array(
			"name" => "Articles",			
			"limits" => array("request" => 20, "total" => 9999),		
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "no"			
		),		
		"avantlink" => array(
			"name" => "Avantlink",			
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "http://www.avantlink.com/"
		),	
		"bestbuy" => array(
			"name" => "BestBuy",			
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "https://developer.bestbuy.com/"
		),			
		"bigcontentsearch" => array(
			"name" => "Big Content Search",			
			"limits" => array("request" => 30, "total" => 500),			
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "http://wprobot.net/go/bigcontentsearch",
			"paid" => 1
		),
		"bingnews" => array(
			"name" => "Bing News",			
			"categories" => array("content"), 
			"icon" => "",
			"signup" => "https://www.microsoft.com/cognitive-services/"
		),		
		"commissionjunction" => array(
			"name" => "Commission Junction",			
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "https://api.cj.com/sign_up.cj"
		),
		"datafeed" => array(
			"name" => "CSV Datafeeds",			
			"categories" => array("shopping","content"), 
			"icon" => "", 
			"signup" => "no"
		),	
		"ebay" => array(	
			"name" => "eBay",			
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "https://www.ebaypartnernetwork.com/files/hub/en-US/index.html"
		),
		"etsy" => array(
			"name" => "Etsy",			
			"limits" => array("request" => 50, "total" => 100000),	
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "http://etsy.com"
		),			
		"eventful" => array(
			"name" => "Eventful",			
			"categories" => array("content","regional"), 
			"icon" => "", 
			"signup" => "http://api.eventful.com/"
		),
		"expedia" => array(
			"name" => "Expedia",			
			"categories" => array("content","shopping"), 
			"icon" => "", 
			"signup" => "http://developer.ean.com/"
		),			
		"flickr" => array(
			"name" => "Flickr",			
			"categories" => array("media","comments"), 
			"icon" => "", 
			"signup" => "http://www.flickr.com/services/"
		),
		"indeed" => array(
			"name" => "Indeed",			
			"categories" => array("content","regional"), 
			"icon" => "", 
			"signup" => "http://www.indeed.com/jsp/apiinfo.jsp"
		),
		"itunes" => array(
			"name" => "iTunes",			
			"limits" => array("request" => 200, "total" => 200),
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "no"
		),	
		/*"kontentmachine" => array(
			"name" => "Kontent Machine",			
			"limits" => array("request" => 200, "total" => 200),
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "wprobot.net/go/kontentmachine"
		),	*/		
		"linkshare" => array(
			"name" => "Linkshare",			
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "http://www.linkshare.com/",			
		),
		"oodle" => array(
			"name" => "Oodle",			
			"unique_direct" => "id",	
			"categories" => array("content","regional"), 
			"icon" => "", 
			"signup" => "http://developer.oodle.com/oodle-api"
		),
		/*"photobucket" => array(
			"name" => "Photobucket",			
			"limits" => array("request" => 50, "total" => 100000),				
			"categories" => array("media"), 
			"icon" => "", 
			"signup" => "http://photobucket.com/developer"
		),	*/
		"pixabay" => array(
			"name" => "Pixabay",			
			"limits" => array("request" => 100, "total" => 1000),			
			"categories" => array("media"), 
			"icon" => "", 
			"signup" => "no"
		),	
		/*"prnewswire" => array(
			"name" => "PR Newswire",	
			"limits" => array("request" => 100, "total" => 500),
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "http://api.prnewswire.com/user/jsp/register.jsp"
		),*/			
		"prosperent" => array(
			"name" => "Prosperent",	
			"limits" => array("request" => 100, "total" => 500),
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "http://prosperent.com/"
		),			
		/*"recipepuppy" => array(
			"name" => "Recipe Buddy",			
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "no"
		),*/	
		"rottentomatoes" => array(
			"name" => "Rotten Tomatoes",			
			"limits" => array("request" => 30, "total" => 100),	
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "http://developer.rottentomatoes.com/"
		),			
		"rss" => array(
			"name" => "RSS Feeds",			
			"categories" => array("content"), 
			"icon" => "", 
			"signup" => "no"
		),			
		"spinchimp" => array(
			"name" => "Spinchimp",			
			"categories" => array("rewriting"), 
			"icon" => "", 
			"signup" => "http://542c4iv7ejm1cq6-snxenhk6kz.hop.clickbank.net/",
			"paid" => 1
		),	
		"spinnerchief" => array(
			"name" => "Spinnerchief",			
			"categories" => array("rewriting"), 
			"icon" => "", 
			"signup" => "http://www.spinnerchief.com/",
			"paid" => 1
		),
		"spinrewriter" => array(
			"name" => "Spinrewriter",			
			"categories" => array("rewriting"), 
			"icon" => "", 
			"signup" => "http://www.spinrewriter.com/?ref=6967",
			"paid" => 1
		),			
		"shopzilla" => array(	
			"name" => "Shopzilla",			
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "https://publisher.shopzilla.com/reg_page1.xhtml"
		),
		"skimlinks" => array(
			"name" => "Skimlinks",			
			"categories" => array("shopping"), 
			"limits" => array("request" => 300, "total" => 1000),	
			"icon" => "", 
			"signup" => "http://api-products.skimlinks.com"
		),		
		"thebestspinner" => array(
			"name" => "TheBestSpinner",			
			"categories" => array("rewriting"), 
			"icon" => "", 
			"signup" => "http://paydotcom.net/r/96144/thoefter/26522731/",
			"paid" => 1
		),	
		"tradedoubler" => array(
			"name" => "Tradedoubler",			
			"limits" => array("request" => 10000, "total" => 100000),	
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "http://tradedoubler.com"
		),				
		"vimeo" => array(
			"name" => "Vimeo",			
			"limits" => array("request" => 50, "total" => 100000),	
			"categories" => array("media"), 
			"icon" => "", 
			"signup" => "http://vimeo.com/api"
		),	
		"walmart" => array(
			"name" => "Walmart",			
			"limits" => array("request" => 50, "total" => 100000),	
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "https://developer.walmartlabs.com"
		),			
		"wordai" => array(
			"name" => "WordAI",			
			"categories" => array("rewriting"), 
			"icon" => "", 
			"signup" => "http://wprobot.net/go/wordai",
			"paid" => 1
		),			
		"yelp" => array(
			"name" => "Yelp",			
			"categories" => array("content","regional"), 
			"icon" => "", 
			"signup" => "http://www.yelp.com/developers/documentation/v2/overview"
		),		
		"youtube" => array(
			"name" => "Youtube",			
			"categories" => array("media","comments"), 
			"icon" => "", 
			"signup" => "https://console.developers.google.com/apis/credentials"
		),	
		"zanox" => array(
			"name" => "Zanox",			
			"limits" => array("request" => 50, "total" => 100000),	
			"categories" => array("shopping"), 
			"icon" => "", 
			"signup" => "http://zanox.com"
		),		
	),		
);

/*** OPTION EXPLANATIONS ***/
$optionsexpl = array(
	"general" => array(
		"options" => array(
		),		
	),
	"youtube" => array(
		"options" => array(
			"width" => array("explanation" => "The video width in pixels.", "link" => ""),	
			"height" => array("explanation" => "The video height in pixels.", "link" => ""),	
			"channel" => array("explanation" => "Enter a Youtube channel name to restrict searches to videos by that channel.", "link" => ""),	
		),		
	),		
	"vimeo" => array(
		"options" => array(
			"width" => array("explanation" => "The video width in pixels.", "link" => ""),	
			"height" => array("explanation" => "The video height in pixels.", "link" => ""),	
			"user_id" => array("explanation" => "Enter a Vimeo username to restrict searches to videos uploaded by the user.", "link" => ""),	
		),		
	),	
	"zanox" => array(
		"options" => array(
			"minprice" => array("explanation" => "Minimum price to search for in USD, e.g. '50' without quotes.", "link" => ""),	
			"maxprice" => array("explanation" => "Maximum price to search for in USD, e.g. '100' without quotes.", "link" => ""),	
		),		
	),		
	"etsy" => array(
		"options" => array(
			"minprice" => array("explanation" => "Minimum price to search for in USD, e.g. '50' without quotes.", "link" => ""),	
			"maxprice" => array("explanation" => "Maximum price to search for in USD, e.g. '100' without quotes.", "link" => ""),	
		),		
	),	
	"tradedoubler" => array(
		"options" => array(
			"minprice" => array("explanation" => "Minimum price to search for in USD, e.g. '50' without quotes.", "link" => ""),	
			"maxprice" => array("explanation" => "Maximum price to search for in USD, e.g. '100' without quotes.", "link" => ""),	
			"language" => array("explanation" => "Restrict searches to a specific language by entering its code, e.g. 'de' for German or 'es' for SPanish.", "link" => ""),	
		),		
	),	
	"amazon" => array(
		"options" => array(
			"searchindex" => array("explanation" => "Limits the search to a specific product category. Please note for 'All' Amazon only returns the first 50 products, so select a specific one if possible.", "link" => ""),			
			"minprice" => array("explanation" => "Minimum price to search for in USD, e.g. '50' without quotes.", "link" => ""),	
			"maxprice" => array("explanation" => __("Maximum price to search for in USD, e.g. '100' without quotes.", "wprobot"), "link" => ""),	
			"minoff" => array("explanation" => __("Use to search for deals and special offers, e.g. enter '30' to only return items with 30% off or more.", "wprobot"), "link" => ""),	
		),		
	),	
	"prosperent" => array(
		"options" => array(
			"merchant" => array("explanation" => "Name of the merchant you want to limit the search to, e.g. 'Zappos' without quotes.", "link" => ""),			
			"minprice" => array("explanation" => "Minimum price to search for in USD, e.g. '50' without quotes.", "link" => ""),	
			"maxprice" => array("explanation" => "Maximum price to search for in USD, e.g. '100' without quotes.", "link" => ""),	
		),		
	),
	"indeed" => array(
		"options" => array(					
			"location" => array("explanation" => 'Use a postal code or a "city, state/province/region" combination.', "link" => ""),
			"radius" => array("explanation" => "Maximum distance from search location in km, e.g. '30'.", "link" => ""),	
		),		
	),	
	"linkshare" => array(
		"options" => array(
			"merchant" => array("explanation" => "Optionally specify a merchant (MID) to limit the search to that merchant’s products.", "link" => ""),
		),			
	),	
	"avantlink" => array(
		"options" => array(
			"websiteid" => array("explanation" => "", "link" => "The website identifier from your Avantlink account."),		
			"lowprice" => array("explanation" => "Minimum price to search for in USD, e.g. '50' without quotes.", "link" => ""),
			"highprice" => array("explanation" => "Maximum price to search for in USD, e.g. '100' without quotes.", "link" => ""),
			"advertisers" => array("explanation" => 'A pipe-delimited list of AvantLink assigned merchant identifiers, e.g. "123|456"', "link" => ""),		
		),		
	),
	"shopzilla" => array(
		"options" => array(	
			"lowprice" => array("explanation" => "Minimum price to search for in USD, e.g. '50' without quotes.", "link" => ""),
			"highprice" => array("explanation" => "Maximum price to search for in USD, e.g. '100' without quotes.", "link" => ""),
			"offers" => array("explanation" => "Number of offers to return per product.", "link" => ""),		
		)
	),		
	"commissionjunction" => array(
		"options" => array(
			"websiteid" => array("explanation" => "The website identifier from your CJ account.", "link" => ""),			
			"lowprice" => array("explanation" => "Minimum price to search for in USD, e.g. '50' without quotes.", "link" => ""),
			"highprice" => array("explanation" => "Maximum price to search for in USD, e.g. '100' without quotes.", "link" => ""),
			"advertisers" => array("explanation" => "Enter 'joined' to search all advertisers you have joined in CJ or a list of one or more advertiser CIDs, separated by comma.", "link" => ""),		
		),
	),
	"eventful" => array(
		"options" => array(
			"cat" => array("explanation" => "", "link" => ""),			
			"location" => array("explanation" => 'Locations in the form "San Diego", "San Diego, TX", "London, United Kingdom", and "Calgary, Alberta, Canada" are accepted, as are postal codes ("92122") and full addresses ("1 Infinite Loop, Cupertino, CA").', "link" => ""),	
		),		
	),
	"oodle" => array(
		"options" => array(
			"cat" => array("explanation" => "Follow this link to see all available categories you can enter.", "link" => "http://developer.oodle.com/categories-list"),			
			"location" => array("explanation" => "You can enter a ZIP code, city, state, location and other values. Click for more details.", "link" => "http://developer.oodle.com/listings#location"),	
			"radius" => array("explanation" => "Maximum distance from search location in km, e.g. '30'.", "link" => ""),	
		),	
	),	
	"yelp" => array(
		"options" => array(
			"location" => array("explanation" => 'Required! Specifies the combination of "address, neighborhood, city, state or zip, optional country" to be used when searching for businesses.', "link" => ""),		
			"radius" => array("explanation" => "Maximum distance from search location in km, e.g. '30'.", "link" => ""),	
		),	
	),
	"datafeed" => array(
		"display" => "no",
		"name" => "CSV Datafeeds",
		"options" => array(
			"delimiter" => array("explanation" => "How fields are separated in your CSV file, commonly by a semicolon, comma or pipe character.", "link" => ""),	
			"enclosure" => array("explanation" => "How fields are enclosed in your CSV file, commonly by a single quote.", "link" => ""),				
			"title" => array("explanation" => "Which number in your CSV file from the left is the title? E.g. if the 1st enter '1'.", "link" => ""),
			"url" => array("explanation" => "Which number in your CSV file from the left is the product URL? E.g. if the 1st enter '1'.", "link" => ""),
			"price" => array("explanation" => "Which number in your CSV file from the left is the price? E.g. if the 1st enter '1'.", "link" => ""),
			"thumbnail" => array("explanation" => "Which number in your CSV file from the left is the thumbnail URL? E.g. if the 1st enter '1'.", "link" => ""),
			"description" => array("explanation" => "Which number in your CSV file from the left is the product description? E.g. if the 1st enter '1'.", "link" => ""),
			"unique" => array("explanation" => "Which number in your CSV file from the left is the unique identifier? E.g. if the 1st enter '1'.", "link" => "")	
		),	
	),		
);

?>