<div class="post-thumbnail thumbnail-audio">
    
    <div class="media-container">
    
        <?php echo wi_get_media_result(); ?>
    
    </div>
</div><!-- .post-thumbnail -->