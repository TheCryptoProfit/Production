<div class="post-thumbnail thumbnail-video">
    <div class="media-container">
    
        <?php echo wi_get_media_result(); ?>
    
    </div>
</div><!-- .post-thumbnail -->