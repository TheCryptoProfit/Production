<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'websites_mockup');

/** MySQL database username */
define('DB_USER', 'websites_mokupad');

/** MySQL database password */
define('DB_PASSWORD', 'X(U]eKTyZ07X');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '[AW*G-oyGKi_VxgCZ-bNxx&pa]gGJ7Kk[j)v4k/Rc2#KYtFRt]>JI,pDNS|DrO#t');
define('SECURE_AUTH_KEY',  '~N1NBV72RHYM;o{vEu@IO+<WE*^XcC.=_av5vm:gr}XS}n8XT&W%]!87GUZ`Gun:');
define('LOGGED_IN_KEY',    'JlD}, +6>K8~Up|fJz[8p^Y}Az82KPL!A,=A@. PnZNtKJ~|^W4W%O<^iN0SOqf|');
define('NONCE_KEY',        '!EHSs^#+K(6bBBTQ;C7l^eg;$]xB^02wN2CWg(f&!#J/4a1Zf<;&2M,_(_9a?[BS');
define('AUTH_SALT',        'b|z.p6>e{iQ(g|.%1BR0k-Q6Jq-=[E_$ncI8/jXTuf2k{<8i06zEL 6e8=VacNbn');
define('SECURE_AUTH_SALT', 'k4O}l=E^v)&=H+8cOG6N|.*;D!NQ;fH#t9k_gQ/x~m%Uqe [JOSX[UPu7rXuvEJ7');
define('LOGGED_IN_SALT',   'K_(f$}d}xo$8DaPI.JAvNR&7={SwK9Op=``T,#5r0/:8Ec{J!m7zE_C37z<`d9Al');
define('NONCE_SALT',       '26(lo`Wg}rV<@/D6@v;<Ix^.{c2H!u.TMi~dz%E.pYu<6CD!H)JntK{&r6X@4Dp6');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
